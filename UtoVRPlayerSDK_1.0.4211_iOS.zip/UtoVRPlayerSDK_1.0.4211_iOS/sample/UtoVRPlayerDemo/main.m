//
//  main.m
//  UtoVRPlayerDemo
//
//  Created by administrator on 12/14/15.
//  Copyright © 2015 xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
