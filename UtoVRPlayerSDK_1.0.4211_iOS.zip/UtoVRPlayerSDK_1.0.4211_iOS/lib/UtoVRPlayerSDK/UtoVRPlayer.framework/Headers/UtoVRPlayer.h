//
//  UtoVRPlayer.h
//  UtoVRPlayer
//
//  Created by administrator on 12/9/15.
//  Copyright © 2015 xue. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UtoVRPlayer.
FOUNDATION_EXPORT double UtoVRPlayerVersionNumber;

//! Project version string for UtoVRPlayer.
FOUNDATION_EXPORT const unsigned char UtoVRPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UtoVRPlayer/PublicHeader.h>

#import <UtoVRPlayer/UVPlayer.h>
#import <UtoVRPlayer/UVPlayerItem.h>